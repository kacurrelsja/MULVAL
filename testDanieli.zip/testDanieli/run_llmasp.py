import json
import os
import re
import yaml
import clingo
from openai import OpenAI

client = OpenAI(api_key=os.getwnv("OPENAI_API_KEY"))

def load_yaml(file_path):
    with open(file_path, "r")as f:
        return yaml.safe_load(f)

def run_llmasp_pipeline(json_input_path, behavior_path, application_path, output_p_path):
    behavior = load_yaml(behavior_path)
    application = load_yaml(application_path)

    with open(json_input_path, "r")as f:
        raw_input_json = json.dumps(json.load(f), indent=2)

    init_prompt = behavior["preprocessing"]["init"]
    context_prompt = application["preprocessing"].get("_","")
    context_prompt = behavior["preprocessing"]["context"].format(context=context_content)

    conversation_history = [
        {"role":"system", "content":f"{init_prompt}\n\n{context_prompt}"}
    ]

    extracted_facts = []

    mapping_template = behavior["preprocessing"]["mapping"]
    for atom_key, instruction in application["preprocessing"].items():
        if atom_key, instruction in application["preprocessing"].items():
            if atom_key == "_":
                continue

        prompt = mapping_template.format(
            input=raw_input_json,
            instructions=instruction,
            atom=atom_key
        )

        response = client.chat.completion.create(
            model="gpt-4o-mini",
            temperature=0.0,
            messages=conversation_history + [{"role":"user","content":prompt}]
        )

        reply = response.choices[0].message.content.strip()

        #Regex to extract [OUTPUT]...[/OUTPUT]
        matches = re.findall(r"\[OUTPUT\](.*?)\[OUTPUT\]", reply, re.DOTALL)
        for match in matches:
            fact = match.strip()
            if fact != "NONE" and fact.endswith("."):
                #Clean up formatting for MulVAL compatibility
                clean_fact = fact.replace('"', '')
                extracted_facts.append(clean_fact)

    print(f"[+] Extracted {len(extracted_facts)} explicit facts from LLM.")

    # P4: ASP Logical Completion via Clingo
    ctl = clingo.Control()

    # Ground extracted facts
    facts_program = " ".join(extracted_facts)
    ctl.add("base", [], asp_kb)

    asp_kb = application.get("knowledge_base", "")
    ctl.add("base", [], asp_kb)

    ctl.ground([("base", [])])

    completed_facts = set(extracted_facts)

    def on_model(model):
        for atom in model.symbols(shown=True):
            fact_str = f"{atom}."
            completed_facts.add(fact_str)

    ctl.solve(on_model=on_model)
    print(f"[+] Total facts after ASP completion: {len(completed_facts)}")

    #Write output to environmentNetwork.P
    with open(output_p_path, "w") as out:
        out.write("/* Auto-generated via LLMASP Pipeline (Alviano et al.) */ \n\n")
        out.write("attackerLocated(internet).\nmaliscious(internet). \n\n")

        for fact in sorted(completed_facts):
            out.write(f"{fact}\n")

        out.write("\n% Core Evaluation Goals\n")
        out.write("attackGoal(domainCompromise(danieli_domain)).\n")
        out.write("attackGoal(unauthoruzedControl(plc_l1_1)).\n")

    print(f"[+] Successfully wrote MulVAL facts to {output_p_path}")

if __name__ == "__main__":
    run_llmasp_pipeline(
        json_input_path="configurations.jjson",
        behavior_path="behavior_ot.yaml",
        application_path="application_ot.yaml",
        output_p_path="environmentNetwork.P"
    )