#!/bin/bash

declare -A GOALS=(
  ["01_DMZ_Ingress"]="execCode(jump_server,admin)"
  ["02_Lateral_Credential_Reuse"]="execCode(vbackup,admin)"
  ["03_Domain_Takeover"]="domainCompromise(danieli_domain)"
  ["04_PLC_Command_Injection"]="unauthorizedControl(plc_l1_1)"
  ["05_PLC_Root_Exec"]="execCode(plc_l1_1,root)"
  ["06_PROFINET_Drive_Control"]="physicalDriveControl(jump_server,drive_area_1_1)"
  ["07_OPCUA_DoS"]="dos(internet,plc_l1_1)"
  ["08_Historian_Data_Tampering"]="processDataTampering(keba_pda_1,iba_hd)"
)

echo "=== Generating MulVAL Attack Graphs for Danieli Scenario ==="

for NAME in "${!GOALS[@]}"; do
  GOAL="${GOALS[$NAME]}"
  echo ""
  echo "[*] Running Scenario: $NAME (Goal: $GOAL)"
  
  graph_gen.sh environmentNetwork.P -r attack1.P -g "$GOAL" -v -p
  
  if [ -f "AttackGraph.pdf" ]; then
    mv AttackGraph.pdf "AttackGraph_${NAME}.pdf"
    echo "[+] Saved: AttackGraph_${NAME}.pdf"
  else
    echo "[-] Warning: AttackGraph.pdf not generated for $NAME"
  fi
done

echo ""
echo "=== All Attack Graphs Generated Successfully ==="